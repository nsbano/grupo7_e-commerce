<?php

<footer>
<div class="footer">
   <div class="footer_1">
       <div class="footer_11">
           <h4>La empresa</h4>
           <ul>
               <li><a href="">Sobre nosotros</a></li>
                   <li><a href="">Política de privacidad</a></li>
                   <li><a href="">Terminos y condiciones</a></li>
               </ul>
           </div>
           <div class="footer_11"  id="medio" >
   <h4>Ayuda</h4>
   <ul>
     <li><a href="contact.html"><ion-icon name="contact"></ion-icon>Contactanos!</a></li>
     <li><a href="faq.html"><ion-icon name="help"></ion-icon>Preguntas frecuentes</a></li>
   </ul>
 </div>

 <div class="footer_11">
   <h4>Atención al cliente</h4>
   <ul>
     <li><ion-icon name="call"></ion-icon>+54 314 316 2969</li>
     <li> Lunes a viernes</li>
     <li> De 8:00 a 20:00 hs</li>
   </ul>
 </div>
 </div>
  <div class="footer_2">
      <div class="afip">
   <a href="http://www.afip.gob.ar/sitio/externos/default.asp" target="_blank"><img src="img/afip.png" alt="Codigo QR AFIP"></a>
 </div>
 </div>
   <div class="footer_3">
       <div class="copyright">
   <p>SportShoes© Copyright 2019. Todos los derechos reservados.</p>
 </div>
</div>
 <div class="footer_4">
     <div class="dh">
   <a href="https://www.digitalhouse.com/" target="_blank"><img src="img/logodh.png" alt=""></a>
 </div>
 </div>
</div>
<script src="https://unpkg.com/ionicons@4.5.10-0/dist/ionicons.js"></script>
</footer>
 ?>
